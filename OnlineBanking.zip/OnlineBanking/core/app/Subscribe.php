<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * @method static findOrFail($id)
 */
class Subscribe extends Model
{
    protected $guarded = ['id'];




}
