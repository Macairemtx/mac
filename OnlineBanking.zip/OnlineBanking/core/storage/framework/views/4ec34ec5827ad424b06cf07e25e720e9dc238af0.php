<?php $__env->startSection('Dashboard', 'active'); ?>
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Dashboard'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('user.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <section class="atop">
      <div class="container">
         <div class="row justify-content-center">
                <div class="col-md-10 col-lg-12 text-center">
                    <div class="heading-title padding-bottom-70">
                        <h2>
                            <?php echo app('translator')->getFromJson('AC'); ?> #<?php echo e(Auth::user()->account_number); ?>

                        </h2>
                        <div class="sectionSeparator"></div>

                    </div>
                </div>
            </div>

          <div class="row aboutTop">
             <div class="col-lg-4">
                 <a href="<?php echo e(route('user.account.statement')); ?>">
                  <div class="box">
                      <i class="fas fa-money-check-alt"></i>
                      <span><?php echo e($gnl->cur_symbol); ?><?php echo e(Auth::user()->balance); ?> </span>
                      <h4><?php echo app('translator')->getFromJson('Current balance'); ?></h4>
                  </div>
                 </a>

              </div>
              <div class="col-lg-4">
                  <a href="<?php echo e(route('user.deposit')); ?>#deposit-log">
                 <div class="box">
                      <i class="fa fa-credit-card-alt"></i>
                      <span><?php echo e($gnl->cur_symbol); ?><?php echo e($totalDep); ?></span>
                      <h4><?php echo app('translator')->getFromJson('Total deposited'); ?></h4>
                 </div>
                  </a>
              </div>
              <div class="col-lg-4">
                  <a href="<?php echo e(route('user.account.statement')); ?>">
                  <div class="box">
                      <i class="fa fa-university"></i>
                      <span><?php echo e($gnl->cur_symbol); ?><?php echo e($totalOtBankTrn); ?></span>
                      <h4><?php echo app('translator')->getFromJson('Pending Other Bank Transaction'); ?></h4>

                  </div>
                   </a>
              </div>
              <div class="col-lg-4">
                  <a href="<?php echo e(route('user.withdraw')); ?>#withdraw-log">
                  <div class="box">
                      <i class="fa fa-reply"></i>
                      <span><?php echo e($gnl->cur_symbol); ?><?php echo e($totalwd); ?></span>
                      <h4><?php echo app('translator')->getFromJson('Total withdrawal'); ?></h4>

                  </div>
                   </a>
              </div>

              <div class="col-lg-4">
                  <a href="<?php echo e(route('user.withdraw')); ?>#withdraw-log">
                  <div class="box">
                      <i class="fa fa-spinner"></i>
                      <span><?php echo e($gnl->cur_symbol); ?><?php echo e($pendingwd); ?></span>
                      <h4><?php echo app('translator')->getFromJson('Withdrawal Pending'); ?></h4>

                  </div>
                   </a>
              </div>
              <div class="col-lg-4">
                  <a href="<?php echo e(route('user.account.statement')); ?>">
                  <div class="box">
                      <i class="fa fa-exchange"></i>
                      <span><?php echo e($totaltf); ?></span>
                      <h4><?php echo app('translator')->getFromJson('Total Transaction'); ?></h4>

                  </div>
                   </a>
              </div>
          </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>