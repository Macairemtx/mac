<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="zxx">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1, user-scalable=0">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <title> <?php echo e($gnl->title); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <!--Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/image/favicon.png')); ?>" type="image/x-icon">
    <!--Bootstrap Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/bootstrap.css')); ?>">
    <!--Font Awesome Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/all.min.css')); ?>">
    <!--Animate Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/animate.css')); ?>">
    <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--YTPlayer  Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/YTPlayer.min.css')); ?>">

    <!--Main Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/video.css')); ?>">
    <!--Responsive Stylesheet-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/responsive.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/toastr.min.css')); ?>">
    <link href="<?php echo e(url('/')); ?>/assets/user/css/color.php?color=<?php echo e($gnl->color1); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body class="body-class">
<!--Start Preloader-->
<div class="site-preloader">
<div class="spinner">
<div class="double-bounce1"></div>
<div class="double-bounce2"></div>
</div>
</div>
<!--End Preloader-->

<!-- Main Menu Area Start -->

<header class="header-area">
    <nav class="navbar sticky-top navbar-expand-lg main-menu">
        <div class="container">

            <a class="navbar-brand" href="<?php echo e(route('homePage')); ?>">
                <img src="<?php echo e(asset('assets/image/logo.png')); ?>"  style="max-width: 220px; max-height: 50px;">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Transfer</a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(route('user.transfer.to.ownbank')); ?>">Own bank</a>
                            <a class="dropdown-item" href="<?php echo e(route('user.transfer.to.otherBank')); ?>">Others Bank</a>
                            <a class="dropdown-item" href="<?php echo e(route('user.withdraw')); ?>">E-currency</a>
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.account.statement')); ?>">Account Statement</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.deposit')); ?>">E-deposit</a></li>

                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('user.branch')); ?>">Our Branch</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->first_name); ?></a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">
                            <a class="dropdown-item" href="<?php echo e(route('user.profile')); ?>"><?php echo app('translator')->getFromJson('Account Settings'); ?></a>
                            <a class="dropdown-item" href="<?php echo e(route('user.changePass')); ?>"><?php echo app('translator')->getFromJson('Change Password'); ?></a>
                            <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>"  onclick="event.preventDefault();
                                        document.getElementById('logout').submit();"><?php echo app('translator')->getFromJson('Log Out'); ?></a>
                            <form id="logout" action="<?php echo e(route('user.logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            </form>

                        </div>
                    </li>
                </ul>
                <div class="viewPlan">
                    <a href="#">
                        <?php echo e(Auth::user()->balance); ?> <?php echo e($gnl->cur); ?>

                    </a>
                </div>
            </div>
        </div>
    </nav>
</header>
<?php echo $__env->yieldContent('content'); ?>

<!-- Footer Area Start -->
<footer id="footer">
    <div class="container">

        <div class="copyright">
            <div class="row">
                <div class="col-md-6 d-flex align-items-center">

                        <div class="banding">
                            <p >
                        <?php echo e($gnl->branding); ?>

                            </p>
                    </div>


                </div>
                <div class="col-md-6 d-flex align-items-center">
                    <div class="box w-100 text-right">
                        <div class="social_links">
                            <ul>
                                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($social->link); ?>">
                                            <i title="<?php echo e($social->name); ?>" class="<?php echo e($social->icon); ?>"></i>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->


<!--Start ClickToTop-->
<div class="totop">
    <a href="#top"><i class="fa fa-arrow-up"></i></a>
</div>
<!--End ClickToTop-->


<script src="<?php echo e(asset('assets/user/js/jquery.min.js')); ?>"></script>
<!--Bootstrap JS-->
<script src="<?php echo e(asset('assets/user/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/user/js/popper.js')); ?>"></script>



<!-- main js -->
<script type="text/javascript" src="<?php echo e(asset('assets/user/js/toastr.min.js')); ?>"></script>
<script>
    
    jQuery(window).on('load', function () 
    
    {

        /*---------------------------------------------------
            Site Preloader
        ----------------------------------------------------*/
        var $sitePreloaderSelector = $('.site-preloader');
        $sitePreloaderSelector.fadeOut(500);


    });
</script>

<!-- main js -->

<?php echo $__env->yieldContent('script'); ?>
<?php echo $__env->make('notification.notification', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>