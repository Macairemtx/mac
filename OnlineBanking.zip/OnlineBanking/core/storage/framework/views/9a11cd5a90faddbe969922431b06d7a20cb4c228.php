<?php $__env->startSection('deposit', 'active'); ?>
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('E-deposit'); ?>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('user.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>





    <section id="investors">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-8 text-center">
                    <div class="heading-title">
                        <h2>
                        <?php echo app('translator')->getFromJson('Deposit methods'); ?>
                        </h2>
                        <div class="sectionSeparator"></div>

                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $gates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-3">
                    <div class="box">
                        <div class="image">
                            <img class="img-fluid" src="<?php echo e(asset('assets/image/gateway')); ?>/<?php echo e($gate->id); ?>.jpg" style="width:100%;"/>
                        </div>
                        <div class="info">
                            <ul class="list-group text-center">
                                <li class="list-group-item">
                                    <h5><?php echo e(__($gate->name)); ?>

                                    </h5>
                                </li>
                                <li class="list-group-item">
                                    <?php echo app('translator')->getFromJson('Limit'); ?>: <strong><?php echo e($gnl->cur_symbol); ?> <?php echo e($gate->minamo); ?></strong> ~ <strong><?php echo e($gnl->cur_symbol); ?> <?php echo e($gate->maxamo); ?></strong>
                                </li>
                                <li class="list-group-item">
                                    <?php echo app('translator')->getFromJson('Charge'); ?>: <strong><?php echo e($gnl->cur_symbol); ?> <?php echo e($gate->fixed_charge); ?></strong> + <strong><?php echo e($gate->percent_charge); ?> %</strong>
                                </li>

                            </ul>
                            <div class="card-footer">
                                <button data-toggle="modal" data-name="<?php echo e(__($gate->name)); ?>" data-gate="<?php echo e($gate->id); ?>"  data-target="#depoModal" class="btn submit-btn depoButton viweBtn" style="width:100%;">
                                    <?php echo app('translator')->getFromJson('Deposit Now'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>




    <section id="transaction p-0">
        <div class="container" id="deposit-log">
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-8 text-center">
                    <div class="heading-title">
                        <h2>
                            <?php echo app('translator')->getFromJson('Deposit Log'); ?>
                        </h2>
                        <div class="sectionSeparator"></div>

                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="tab1">

                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade active show" id="pills-deposit" role="tabpanel" aria-labelledby="pills-deposit-tab">
                                <div class="table-responsive">
                                    <table class="table table-hover text-center">
                                        <thead>
                                        <tr>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('Amount'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('Gateway'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('TRX ID'); ?></th>
                                            <th class="text-center"><?php echo app('translator')->getFromJson('TRX Time'); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($deposit)==0): ?>
                                            <tr>
                                                <td colspan="4"><h2><?php echo app('translator')->getFromJson('No Data Available'); ?></h2></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($log->amount); ?> <?php echo e($gnl->cur); ?></td>
                                                <td><?php echo e($log->gateway->name); ?></td>
                                                <td><?php echo e($log->trx); ?></td>
                                                <td><?php echo e($log->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>

                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <div class="d-flex justify-content-end">
                    <?php echo e($deposit->links()); ?>

                </div>
            </div>

        </div>

    </section>




    <!-- Modal -->
    <div class="modal fade" id="depoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="ModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('user.deposit.data-insert')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="gateway" id="gateWay"/>
                        <div class="form-group">
                            <h5><?php echo app('translator')->getFromJson('Enter Deposit Amount'); ?></h5>
                            <div class="input-group-append">
                                <input type="text" name="amount" class="form-control form-control-lg"/>
                                <span class="input-group-text"><?php echo e($gnl->cur); ?></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn viweBtn" style="width:100%;"><?php echo app('translator')->getFromJson('Deposit Preview'); ?></button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->getFromJson('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>

        $(document).ready(function(){
            $(document).on('click','.depoButton', function(){
                $('#ModalLabel').text($(this).data('name'));
                $('#gateWay').val($(this).data('gate'));
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>