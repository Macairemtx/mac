<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo e(__($gnl->title)); ?></title>
</head>

<body>
    <?php echo $form; ?>
<script>
    document.getElementById("coinPayForm").submit();
</script>
</body>

</html>
    
	