<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('Sign Up'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section id="paymentMethod">
        <div class="container">
           
            <div class="row calculate justify-content-center">
                <div class="col-md-12 col-lg-10">
                    <div class="box">

                        <form method="post" action="<?php echo e(route('register')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-row">
                                        <div class="form-group col-md-6">

                                            <input type="text" name="first_name" class="myForn" placeholder="<?php echo app('translator')->getFromJson('First Name'); ?>" required>
                                        </div>
                                        <div class="form-group col-md-6">

                                            <input type="text"  name="last_name" class="myForn" placeholder="<?php echo app('translator')->getFromJson('Last Name'); ?>"  required>
                                        </div>

                                        <div class="form-group col-md-6">
                                            <input type="email"  name="email" class="myForn" placeholder="<?php echo app('translator')->getFromJson('Email'); ?>"  required>
                                        </div>
                                        <div class="form-group col-md-6">

                                            <input type="text"  name="phone" class="myForn" placeholder="<?php echo app('translator')->getFromJson('Phone Number'); ?>"  required>
                                        </div>

                                        <div class="form-group col-md-12">

                                            <input type="text" name="username" class="myForn" placeholder="<?php echo app('translator')->getFromJson('Username'); ?>"  required>
                                        </div>
                                        <div class="form-group col-md-6">

                                            <input type="password"  name="password" class="myForn" placeholder="<?php echo app('translator')->getFromJson('Password'); ?>"  required>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <input type="password"   class="myForn" name="password_confirmation"  placeholder="<?php echo app('translator')->getFromJson('Confirm Password'); ?>"  required>
                                        </div>
                                    </div>
                                </div>

                                        <div class="form-group padding-top-10 col-md-12">
                                            <button class="btn" type="submit"><?php echo app('translator')->getFromJson('Register'); ?></button>
                                        </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>