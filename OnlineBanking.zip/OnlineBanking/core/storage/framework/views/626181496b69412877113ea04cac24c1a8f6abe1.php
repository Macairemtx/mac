

<?php if($errors->any()): ?>
    <script>
        $(document).ready(function () {
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            toastr.error('<?php echo e($error); ?>')
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
<?php endif; ?>

<?php if(session()->has('success')): ?>
    <script>
        $(document).ready(function () {
            toastr.success('<?php echo e(session('success')); ?>');
        });
    </script>
<?php endif; ?>
