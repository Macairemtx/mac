<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{__($gnl->title)}}</title>
</head>

<body>
    @php echo $form; @endphp
<script>
    document.getElementById("coinPayForm").submit();
</script>
</body>

</html>
    
	