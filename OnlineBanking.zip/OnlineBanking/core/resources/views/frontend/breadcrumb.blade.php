
<section id="welcomeArea" style="background: url({{asset('assets/image/breadcrumb.jpg')}}) no-repeat top;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 text-center">
                <div class="topcontent-bank">
                    <h1>@yield('title')</h1>
                </div>
            </div>
        </div>
    </div>
</section>



